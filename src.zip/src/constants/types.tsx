export type RootStackParamList = {
  HomeScreen: undefined;
  Profile: undefined;
  LoginScreen: undefined;
  MyDrawer: undefined; // Add any other routes and their parameters here
};
